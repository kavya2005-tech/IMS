<?php
include '../includes/header.php';
require '../config/db.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit;
}

// Generate report data
try {
    // Total quantity of each product in inventory
    $productReportStmt = $pdo->prepare("
        SELECT p.name AS product_name, SUM(i.quantity) AS total_quantity
        FROM products p
        LEFT JOIN inventory i ON p.id = i.product_id
        GROUP BY p.id
    ");
    $productReportStmt->execute();
    $productReport = $productReportStmt->fetchAll();

    // Inventory data grouped by suppliers
    $supplierReportStmt = $pdo->prepare("
        SELECT s.name AS supplier_name, SUM(i.quantity) AS total_quantity
        FROM suppliers s
        LEFT JOIN inventory i ON s.id = i.supplier_id
        GROUP BY s.id
    ");
    $supplierReportStmt->execute();
    $supplierReport = $supplierReportStmt->fetchAll();

    // Inventory history
    $inventoryHistoryStmt = $pdo->prepare("
        SELECT p.name AS product_name, s.name AS supplier_name, i.quantity, i.date
        FROM inventory i
        JOIN products p ON i.product_id = p.id
        JOIN suppliers s ON i.supplier_id = s.id
        ORDER BY i.date DESC
    ");
    $inventoryHistoryStmt->execute();
    $inventoryHistory = $inventoryHistoryStmt->fetchAll();
} catch (PDOException $e) {
    echo "Error generating report: " . $e->getMessage();
    die();
}
?>

<div class="container mt-5">
    <h2>Inventory Reports</h2>

    <!-- Total Quantity per Product -->
    <h3 class="mt-4">Total Quantity per Product</h3>
    <div class="table-responsive">
        <table class="table table-bordered table-striped">
            <thead class="thead-dark">
                <tr>
                    <th>Product Name</th>
                    <th>Total Quantity</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($productReport as $product): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($product['product_name']); ?></td>
                        <td><?php echo htmlspecialchars($product['total_quantity']); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <!-- Total Quantity by Supplier -->
    <h3 class="mt-4">Total Quantity by Supplier</h3>
    <div class="table-responsive">
        <table class="table table-bordered table-striped">
            <thead class="thead-dark">
                <tr>
                    <th>Supplier Name</th>
                    <th>Total Quantity</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($supplierReport as $supplier): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($supplier['supplier_name']); ?></td>
                        <td><?php echo htmlspecialchars($supplier['total_quantity']); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <!-- Inventory History -->
    <h3 class="mt-4">Inventory History</h3>
    <div class="table-responsive">
        <table class="table table-bordered table-striped">
            <thead class="thead-dark">
                <tr>
                    <th>Product Name</th>
                    <th>Supplier Name</th>
                    <th>Quantity</th>
                    <th>Date</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($inventoryHistory as $entry): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($entry['product_name']); ?></td>
                        <td><?php echo htmlspecialchars($entry['supplier_name']); ?></td>
                        <td><?php echo htmlspecialchars($entry['quantity']); ?></td>
                        <td><?php echo htmlspecialchars(date("Y-m-d", strtotime($entry['date']))); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
