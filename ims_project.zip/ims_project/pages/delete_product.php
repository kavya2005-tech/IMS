<?php
session_start();
require '../config/db.php'; // Include your database connection

// Check if product ID is provided
if (isset($_GET['id'])) {
    $product_id = $_GET['id'];

    // Check if product exists
    $stmt = $pdo->prepare("SELECT * FROM products WHERE id = :id");
    $stmt->execute(['id' => $product_id]);
    $product = $stmt->fetch();

    if ($product) {
        // Delete the product
        $stmt = $pdo->prepare("DELETE FROM products WHERE id = :id");
        $stmt->execute(['id' => $product_id]);

        // Redirect after successful deletion
        header("Location: products.php?msg=Product deleted successfully");
        exit();
    } else {
        die("Product not found!");
    }
} else {
    die("Invalid product ID!");
}
?>
