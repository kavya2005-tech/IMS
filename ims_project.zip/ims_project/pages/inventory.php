<?php
include '../includes/header.php';
require '../config/db.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit;
}

// Fetch inventory data with product and supplier names for easy reference
try {
    $stmt = $pdo->prepare("
        SELECT i.id, p.name AS product_name, s.name AS supplier_name, i.quantity, i.date
        FROM inventory i
        JOIN products p ON i.product_id = p.id
        JOIN suppliers s ON i.supplier_id = s.id
    ");
    $stmt->execute();
    $inventory = $stmt->fetchAll();
} catch (PDOException $e) {
    echo "Error fetching inventory data: " . $e->getMessage();
    die();
}
?>

<div class="container mt-5">
    <h2>Inventory Management</h2>
    <a href="add_inventory.php" class="btn btn-primary mb-3">Add New Inventory Entry</a>

    <!-- Inventory Table -->
    <div class="table-responsive">
        <table class="table table-striped table-hover">
            <thead class="thead-dark">
                <tr>
                    <th>ID</th>
                    <th>Product Name</th>
                    <th>Supplier Name</th>
                    <th>Quantity</th>
                    <th>Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($inventory)): ?>
                    <?php foreach ($inventory as $item): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($item['id']); ?></td>
                            <td><?php echo htmlspecialchars($item['product_name']); ?></td>
                            <td><?php echo htmlspecialchars($item['supplier_name']); ?></td>
                            <td><?php echo htmlspecialchars($item['quantity']); ?></td>
                            <td><?php echo htmlspecialchars(date("Y-m-d", strtotime($item['date']))); ?></td>
                            <td>
                                <a href="update_inventory.php?id=<?php echo htmlspecialchars($item['id']); ?>" class="btn btn-sm btn-warning">Update</a>
                                <a href="delete_inventory.php?id=<?php echo htmlspecialchars($item['id']); ?>" class="btn btn-sm btn-danger">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="6" class="text-center">No inventory records found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
