<?php
include '../includes/header.php';
require '../config/db.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit;
}

// Fetch product and supplier data for dropdown options
try {
    $productStmt = $pdo->prepare("SELECT id, name FROM products");
    $productStmt->execute();
    $products = $productStmt->fetchAll();

    $supplierStmt = $pdo->prepare("SELECT id, name FROM suppliers");
    $supplierStmt->execute();
    $suppliers = $supplierStmt->fetchAll();
} catch (PDOException $e) {
    echo "Error fetching data: " . $e->getMessage();
    die();
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $product_id = $_POST['product_id'] ?? null;
    $supplier_id = $_POST['supplier_id'] ?? null;
    $quantity = $_POST['quantity'] ?? null;
    $date = $_POST['date'] ?? null;

    // Validation and inserting new inventory record
    if ($product_id && $supplier_id && $quantity && $date) {
        try {
            $stmt = $pdo->prepare("
                INSERT INTO inventory (product_id, supplier_id, quantity, date)
                VALUES (:product_id, :supplier_id, :quantity, :date)
            ");
            $stmt->execute([
                ':product_id' => $product_id,
                ':supplier_id' => $supplier_id,
                ':quantity' => $quantity,
                ':date' => $date
            ]);
            echo "<div class='alert alert-success'>Inventory entry added successfully.</div>";
        } catch (PDOException $e) {
            echo "<div class='alert alert-danger'>Error adding inventory: " . $e->getMessage() . "</div>";
        }
    } else {
        echo "<div class='alert alert-warning'>Please fill in all fields.</div>";
    }
}
?>

<div class="container mt-5">
    <h2>Add Inventory Entry</h2>
    <form method="POST" action="">
        <div class="form-group">
            <label for="product_id">Product</label>
            <select name="product_id" id="product_id" class="form-control" required>
                <option value="">Select Product</option>
                <?php foreach ($products as $product): ?>
                    <option value="<?php echo htmlspecialchars($product['id']); ?>">
                        <?php echo htmlspecialchars($product['name']); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group">
            <label for="supplier_id">Supplier</label>
            <select name="supplier_id" id="supplier_id" class="form-control" required>
                <option value="">Select Supplier</option>
                <?php foreach ($suppliers as $supplier): ?>
                    <option value="<?php echo htmlspecialchars($supplier['id']); ?>">
                        <?php echo htmlspecialchars($supplier['name']); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group">
            <label for="quantity">Quantity</label>
            <input type="number" name="quantity" id="quantity" class="form-control" required min="1">
        </div>

        <div class="form-group">
            <label for="date">Date</label>
            <input type="date" name="date" id="date" class="form-control" required>
        </div>

        <button type="submit" class="btn btn-primary">Add Inventory</button>
        <a href="inventory.php" class="btn btn-secondary">Back to Inventory</a>
    </form>
</div>

<?php include '../includes/footer.php'; ?>
