<?php
session_start();
require '../config/db.php'; // Include database connection

// Check if database connection is established
if (!isset($pdo)) {
    die("Database connection not established.");
}

// Initialize error and success messages
$error_message = "";
$success_message = "";

// Fetch the supplier's current details if an ID is provided
if (isset($_GET['id'])) {
    $supplier_id = $_GET['id'];
    
    // Fetch the supplier's information from the database
    try {
        $stmt = $pdo->prepare("SELECT * FROM suppliers WHERE id = ?");
        $stmt->execute([$supplier_id]);
        $supplier = $stmt->fetch();

        // Check if supplier exists
        if (!$supplier) {
            $error_message = "Supplier not found.";
        }
    } catch (PDOException $e) {
        $error_message = "Error fetching supplier details: " . $e->getMessage();
    }
} else {
    $error_message = "No supplier ID provided.";
}

// Handle form submission to update supplier details
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve updated details from form submission
    $name = trim($_POST['name']);
    $contact = trim($_POST['contact']);
    $email = trim($_POST['email']);
    $address = trim($_POST['address']);

    // Basic validation
    if (empty($name) || empty($contact) || empty($email) || empty($address)) {
        $error_message = "All fields are required.";
    } else {
        try {
            // Prepare SQL update statement
            $stmt = $pdo->prepare("UPDATE suppliers SET name = ?, contact = ?, email = ?, address = ? WHERE id = ?");
            $stmt->execute([$name, $contact, $email, $address, $supplier_id]);

            $success_message = "Supplier updated successfully.";
        } catch (PDOException $e) {
            $error_message = "Error updating supplier: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Supplier</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h2>Edit Supplier</h2>

        <?php if (!empty($error_message)): ?>
            <div class="alert alert-danger">
                <?php echo htmlspecialchars($error_message); ?>
            </div>
        <?php elseif (!empty($success_message)): ?>
            <div class="alert alert-success">
                <?php echo htmlspecialchars($success_message); ?>
            </div>
        <?php endif; ?>

        <?php if (isset($supplier) && $supplier): ?>
            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]) . '?id=' . $supplier_id; ?>" method="post">
                <div class="form-group">
                    <label for="name">Supplier Name:</label>
                    <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($supplier['name']); ?>" required>
                </div>
                <div class="form-group">
                    <label for="contact">Contact:</label>
                    <input type="text" class="form-control" id="contact" name="contact" value="<?php echo htmlspecialchars($supplier['contact']); ?>" required>
                </div>
                <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($supplier['email']); ?>" required>
                </div>
                <div class="form-group">
                    <label for="address">Address:</label>
                    <input type="text" class="form-control" id="address" name="address" value="<?php echo htmlspecialchars($supplier['address']); ?>" required>
                </div>
                <button type="submit" class="btn btn-primary">Update Supplier</button>
                <a href="suppliers.php" class="btn btn-secondary">Cancel</a>
            </form>
        <?php endif; ?>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
