<?php
session_start();
require '../config/db.php'; // Include your database connection file

// Check if the database connection is established
if (!isset($pdo)) {
    die("Database connection not established.");
}

// Check if a valid supplier ID is provided via GET
if (isset($_GET['id'])) {
    $supplier_id = $_GET['id'];
    
    try {
        // Prepare SQL delete statement
        $stmt = $pdo->prepare("DELETE FROM suppliers WHERE id = ?");
        
        // Execute the delete statement
        if ($stmt->execute([$supplier_id])) {
            // Redirect to suppliers list after successful deletion
            $_SESSION['success_message'] = "Supplier deleted successfully.";
        } else {
            $_SESSION['error_message'] = "Error deleting supplier.";
        }
    } catch (PDOException $e) {
        $_SESSION['error_message'] = "Error deleting supplier: " . $e->getMessage();
    }
} else {
    $_SESSION['error_message'] = "No supplier ID provided.";
}

// Redirect to suppliers page
header("Location: suppliers.php");
exit();
