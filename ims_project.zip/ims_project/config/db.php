<?php
$host = 'localhost'; // Usually localhost
$db = 'ims'; // Your actual database name
$user = 'root'; // Your database username (default is usually root for XAMPP)
$pass = ''; // Your database password (leave empty if no password)

try {
    // Create a PDO instance
    $conn = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
    // Set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    // Handle connection error
    echo "Connection failed: " . $e->getMessage();
    exit; // Stop script execution if the connection fails
}
?>
