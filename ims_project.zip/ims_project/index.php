<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventory Management System</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/styles.css"> <!-- Link to your custom CSS -->
    <style>
        .auth-buttons {
            position: absolute;
            top: 20px;
            right: 20px;
        }
        .auth-buttons .btn {
            margin-left: 10px;
        }
        .hero-section {
            text-align: center;
            padding: 50px 0;
            background-color: #f8f9fa;
            border-radius: 8px;
        }
        .card img {
            height: 200px;
            object-fit: cover;
        }
        .features-section {
            background-color: #f0f8ff;
            padding: 50px 0;
        }
        .testimonial-section {
            background-color: #f8f9fa;
            padding: 50px 0;
        }
        .testimonials {
            font-style: italic;
            color: #555;
        }
    </style>
</head>
<body>
    <!-- Header with Login/Register buttons -->
    <?php include 'includes/header.php'; ?>

    <!-- Authentication Buttons -->
    <div class="auth-buttons">
        <a href="auth/login.php" class="btn btn-primary">Login</a>
        <a href="auth/register.php" class="btn btn-success">Register</a>
    </div>

    <div class="container mt-5">
        <div class="hero-section">
            <h1>Welcome to the Inventory Management System !</h1>
            <p>Your complete solution for managing inventory efficiently.</p>
        </div>

        <div class="row mt-5">
            <div class="col-md-4">
                <div class="card text-center">
                    <img src="assets/images/inventory.jpg" class="card-img-top" alt="Inventory">
                    <div class="card-body">
                        <h5 class="card-title">Manage Your Inventory</h5>
                        <p class="card-text">Easily track your stock levels and manage products.</p>
                        <a href="auth/login.php" class="btn btn-primary">Get Started</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card text-center">
                    <img src="assets/images/supplier.jpg" class="card-img-top" alt="Suppliers">
                    <div class="card-body">
                        <h5 class="card-title">Supplier Management</h5>
                        <p class="card-text">Keep track of your suppliers and their products.</p>
                        <a href="auth/login.php" class="btn btn-primary">Explore</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card text-center">
                    <img src="assets/images/report.jpg" class="card-img-top" alt="Reports">
                    <div class="card-body">
                        <h5 class="card-title">Comprehensive Reports</h5>
                        <p class="card-text">Generate detailed reports to analyze your inventory data.</p>
                        <a href="pages/reports.php" class="btn btn-primary">View Reports</a>
                    </div>
                </div>
            </div>
        </div>

        <div class="features-section text-center mt-5">
            <h2>Key Features</h2>
            <ul class="list-unstyled">
                <li>📦 Easy Inventory Tracking</li>
                <li>👤 Supplier Management</li>
                <li>📊 Detailed Reporting</li>
                <li>⚙️ User-Friendly Interface</li>
                <li>🔒 Secure Access Control</li>
            </ul>
        </div>

        <div class="testimonial-section text-center mt-5">
            <h2>What Our Users Say</h2>
            <p class="testimonials">"This inventory system has transformed the way we manage our stock. Highly recommend!" </p>
            <p class="testimonials">"User-friendly and efficient. It has significantly improved our operations."</p>
        </div>

        <div class="text-center mt-5">
            <h2>Simplify your inventory management with real-time insights and analytics</h2>
            <p>Our system is designed to streamline your inventory management process, ensuring efficiency and accuracy.</p>
        </div>
    </div>

    <?php include 'includes/footer.php'; ?>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
